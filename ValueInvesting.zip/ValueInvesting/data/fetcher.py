from __future__ import annotations

import math
import re
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Callable

import akshare as ak
import pandas as pd
import requests

from .storage import CacheStorage


class DataFetchError(RuntimeError):
    """Raised when live data and acceptable cached data are both unavailable."""


class StockNotFoundError(LookupError):
    """Raised when a valid-looking code is not present in the A-share quote list."""


def normalize_code(value: str) -> str:
    code = re.sub(r"\D", "", str(value).strip())
    if len(code) != 6:
        raise ValueError("请输入 6 位 A 股代码，例如 600519。")
    if not code.startswith(("0", "3", "6", "8", "4")):
        raise ValueError("该代码不属于常见 A 股代码范围。")
    return code


@dataclass
class DataResult:
    data: Any
    source: str
    fetched_at: str
    stale: bool = False

    def meta(self) -> dict:
        return {
            "source": self.source,
            "fetched_at": self.fetched_at,
            "stale": self.stale,
        }


class StockDataFetcher:
    def __init__(self, storage: CacheStorage, config: dict):
        self.storage = storage
        self.config = config
        self.interval = float(config.get("request_interval_seconds", 0.35))
        self.retries = int(config.get("retries", 2))
        self.stale_seconds = float(config.get("allow_stale_cache_days", 14)) * 86400
        self._last_request = 0.0
        self._request_lock = threading.Lock()

    def _throttle(self) -> None:
        with self._request_lock:
            elapsed = time.monotonic() - self._last_request
            if elapsed < self.interval:
                time.sleep(self.interval - elapsed)
            self._last_request = time.monotonic()

    def _retry(self, operation: Callable[[], Any]) -> Any:
        last_error: Exception | None = None
        for attempt in range(self.retries):
            try:
                self._throttle()
                return operation()
            except Exception as error:  # public data endpoints fail in varied ways
                last_error = error
                if attempt + 1 < self.retries:
                    time.sleep(0.8 * (attempt + 1))
        raise DataFetchError(str(last_error or "数据源请求失败"))

    def _cached_or_fetch(
        self,
        key: str,
        max_age_seconds: float,
        fetch: Callable[[], Any],
        source: str,
    ) -> DataResult:
        fresh = self.storage.get(key, max_age_seconds)
        if fresh:
            return DataResult(fresh["payload"], fresh["source"], fresh["fetched_at"])
        try:
            payload = _to_json_value(self._retry(fetch))
            self.storage.put(key, payload, source)
            saved = self.storage.get(key)
            assert saved is not None
            return DataResult(saved["payload"], source, saved["fetched_at"])
        except Exception as error:
            stale = self.storage.get(key, self.stale_seconds)
            if stale:
                return DataResult(stale["payload"], stale["source"], stale["fetched_at"], True)
            if isinstance(error, DataFetchError):
                raise
            raise DataFetchError(str(error)) from error

    def get_quote(self, code: str) -> DataResult:
        code = normalize_code(code)
        result = self.get_quote_list()
        quote = next((item for item in result.data if item["code"] == code), None)
        if quote is None:
            raise StockNotFoundError(f"未找到股票代码 {code}，请确认代码仍在上市交易。")
        return DataResult(quote, result.source, result.fetched_at, result.stale)

    def get_quote_list(self) -> DataResult:
        """Return normalized A-share quotes for startup ranking and single-stock lookup."""
        ttl = float(self.config.get("quote_cache_minutes", 15)) * 60

        def fetch_eastmoney() -> list[dict]:
            frame = ak.stock_zh_a_spot_em()
            if frame is None or frame.empty:
                raise DataFetchError("实时行情返回为空")
            return frame.to_dict(orient="records")

        def fetch_sina() -> list[dict]:
            frame = ak.stock_zh_a_spot()
            if frame is None or frame.empty:
                raise DataFetchError("新浪实时行情返回为空")
            return frame.to_dict(orient="records")

        errors: list[str] = []
        for key, operation, source in (
            ("quotes:a-share:eastmoney", fetch_eastmoney, "东方财富实时行情"),
            ("quotes:a-share:sina", fetch_sina, "新浪财经实时行情"),
        ):
            try:
                result = self._cached_or_fetch(key, ttl, operation, source)
                quotes = [
                    _normalize_quote(row, row_code)
                    for row in result.data
                    if (row_code := _row_code(row))
                ]
                if quotes:
                    return DataResult(quotes, result.source, result.fetched_at, result.stale)
            except DataFetchError as error:
                errors.append(f"{source}：{error}")

        raise DataFetchError("；".join(errors) or "所有实时行情源均不可用")

    def get_hot_rank(self, limit: int = 200) -> DataResult:
        """Combine Eastmoney's current-popularity and popularity-rising lists."""
        ttl = float(self.config.get("hot_rank_cache_minutes", 30)) * 60

        def fetch_hot_rank() -> list[dict]:
            common = {
                "appId": "appId01",
                "globalId": "786e4c21-70dc-435a-93bb-38",
                "marketType": "",
                "pageNo": 1,
                "pageSize": 100,
            }
            endpoints = (
                ("https://emappdata.eastmoney.com/stockrank/getAllCurrentList", "rk", "人气榜"),
                ("https://emappdata.eastmoney.com/stockrank/getAllHisRcList", "hrcrk", "飙升榜"),
            )
            ranked: list[dict] = []
            seen: set[str] = set()
            for url, rank_field, list_name in endpoints:
                response = requests.post(url, json=common, timeout=20)
                response.raise_for_status()
                rows = response.json().get("data") or []
                for row in rows:
                    code = _row_code({"代码": row.get("sc")})
                    if not code or code in seen or not code.startswith(("0", "3", "6", "8", "4")):
                        continue
                    seen.add(code)
                    ranked.append(
                        {
                            "code": code,
                            "heat_rank": len(ranked) + 1,
                            "source_rank": int(_number(row.get(rank_field)) or len(ranked) + 1),
                            "heat_list": list_name,
                        }
                    )
                    if len(ranked) >= limit:
                        return ranked
            if not ranked:
                raise DataFetchError("东方财富人气榜返回为空")
            return ranked

        return self._cached_or_fetch(
            f"hot-rank:eastmoney:combined:{limit}:v2",
            ttl,
            fetch_hot_rank,
            "东方财富人气榜与飙升榜",
        )

    def get_history(self, code: str, days: int = 120) -> DataResult:
        code = normalize_code(code)
        ttl = float(self.config.get("history_cache_hours", 12)) * 3600
        end = datetime.now().strftime("%Y%m%d")
        start = (datetime.now() - timedelta(days=days * 2)).strftime("%Y%m%d")

        def fetch_eastmoney_history() -> list[dict]:
            frame = ak.stock_zh_a_hist(
                symbol=code,
                period="daily",
                start_date=start,
                end_date=end,
                adjust="qfq",
            )
            if frame is None or frame.empty:
                raise DataFetchError("历史行情返回为空")
            return _normalize_history_frame(frame, days)

        def fetch_sina_history() -> list[dict]:
            market_code = (
                f"sh{code}" if code.startswith("6") else
                f"bj{code}" if code.startswith(("4", "8")) else
                f"sz{code}"
            )
            frame = ak.stock_zh_a_daily(
                symbol=market_code,
                start_date=start,
                end_date=end,
                adjust="qfq",
            )
            if frame is None or frame.empty:
                raise DataFetchError("新浪历史行情返回为空")
            return _normalize_history_frame(frame, days)

        errors: list[str] = []
        for key, operation, source in (
            (f"history:{code}:{days}:eastmoney", fetch_eastmoney_history, "东方财富前复权日线"),
            (f"history:{code}:{days}:sina", fetch_sina_history, "新浪财经前复权日线"),
        ):
            try:
                return self._cached_or_fetch(key, ttl, operation, source)
            except DataFetchError as error:
                errors.append(f"{source}：{error}")
        raise DataFetchError("；".join(errors))

    def get_financials(self, code: str) -> DataResult:
        code = normalize_code(code)
        ttl = float(self.config.get("financial_cache_hours", 24)) * 3600

        def fetch_financials() -> dict:
            frame = self._fetch_financial_frame(code)
            if frame is None or frame.empty:
                raise DataFetchError("财务指标返回为空")
            row = _latest_financial_row(frame)
            return _normalize_financial_row(row)

        return self._cached_or_fetch(
            f"financials:{code}",
            ttl,
            fetch_financials,
            "AkShare 财务分析指标",
        )

    def get_market_financials(self) -> DataResult:
        """Fetch one report-period snapshot for the whole market in a single paged request."""
        report_date = _latest_complete_report_date()
        ttl = float(self.config.get("financial_cache_hours", 24)) * 3600

        def fetch_market_financials() -> dict:
            frame = ak.stock_yjbb_em(date=report_date)
            if frame is None or frame.empty:
                raise DataFetchError(f"{report_date} 批量财务数据返回为空")
            stocks: dict[str, dict] = {}
            annualization = {"03": 4.0, "06": 2.0, "09": 4.0 / 3.0, "12": 1.0}[report_date[4:6]]
            for row in frame.to_dict(orient="records"):
                code = _row_code({"代码": row.get("股票代码")})
                if not code:
                    continue
                revenue = _number(row.get("营业总收入-营业总收入"))
                profit = _number(row.get("净利润-净利润"))
                eps = _number(row.get("每股收益"))
                book_value = _number(row.get("每股净资产"))
                stocks[code] = {
                    "report_date": report_date,
                    "roe": _number(row.get("净资产收益率")),
                    "net_margin": profit / revenue * 100 if profit is not None and revenue else None,
                    "revenue_growth": _number(row.get("营业总收入-同比增长")),
                    "profit_growth": _number(row.get("净利润-同比增长")),
                    "debt_ratio": None,
                    "current_ratio": None,
                    "operating_cashflow_per_share": _number(row.get("每股经营现金流量")),
                    "eps": eps,
                    "book_value_per_share": book_value,
                    "annualized_eps": eps * annualization if eps is not None else None,
                }
            if not stocks:
                raise DataFetchError("批量财务数据无法识别股票代码")
            return {"report_date": report_date, "stocks": stocks}

        return self._cached_or_fetch(
            f"financials:market:{report_date}",
            ttl,
            fetch_market_financials,
            "东方财富批量业绩报表",
        )

    def _fetch_financial_frame(self, code: str) -> pd.DataFrame:
        errors: list[str] = []
        candidates: list[Callable[[], pd.DataFrame]] = []
        em_function = getattr(ak, "stock_financial_analysis_indicator_em", None)
        if callable(em_function):
            candidates.append(lambda: em_function(symbol=code, indicator="按报告期"))
        legacy_function = getattr(ak, "stock_financial_analysis_indicator", None)
        if callable(legacy_function):
            candidates.append(lambda: legacy_function(symbol=code))

        for operation in candidates:
            try:
                frame = self._retry(operation)
                if frame is not None and not frame.empty:
                    return frame
            except Exception as error:
                errors.append(str(error))
        raise DataFetchError("；".join(errors) or "当前 AkShare 版本不支持财务指标接口")


def resolve_scoring_financials(
    fetcher,
    code: str,
    market_result: DataResult | None = None,
) -> DataResult:
    """Return one period-consistent financial set, with market data as fallback."""
    scoring_fields = (
        "roe",
        "net_margin",
        "revenue_growth",
        "profit_growth",
        "debt_ratio",
        "current_ratio",
        "operating_cashflow_per_share",
        "eps",
    )
    individual: DataResult | None = None
    individual_error: Exception | None = None
    try:
        individual = fetcher.get_financials(code)
    except (DataFetchError, RuntimeError, ValueError) as error:
        individual_error = error

    needs_supplement = individual is None or any(
        individual.data.get(field) is None for field in scoring_fields
    )
    if needs_supplement and market_result is None:
        try:
            market_result = fetcher.get_market_financials()
        except (AttributeError, DataFetchError, RuntimeError, ValueError):
            market_result = None

    market_financials: dict = {}
    if market_result is not None and isinstance(market_result.data, dict):
        market_financials = market_result.data.get("stocks", {}).get(code, {}) or {}

    if individual is None and not market_financials:
        raise DataFetchError(str(individual_error or "财务数据不可用"))

    individual_period = _report_period(individual.data.get("report_date")) if individual else None
    market_period = _report_period(market_financials.get("report_date"))
    same_period = bool(individual_period and individual_period == market_period)

    if individual is not None and market_financials and same_period:
        merged = dict(market_financials)
        merged.update({key: value for key, value in individual.data.items() if value is not None})
        source = f"{individual.source}（同报告期缺失项由{market_result.source}补齐）"
        fetched_at = individual.fetched_at or market_result.fetched_at
        stale = individual.stale or market_result.stale
    elif individual is not None:
        merged = dict(individual.data)
        source = individual.source
        if market_financials and individual_period != market_period:
            source += "（批量财务报告期不同，未跨期合并）"
        fetched_at = individual.fetched_at
        stale = individual.stale
    else:
        merged = dict(market_financials)
        source = f"{market_result.source}（单股接口失败，批量财务回退）"
        fetched_at = market_result.fetched_at
        stale = market_result.stale

    return DataResult(merged, source, fetched_at, stale)


def _report_period(value: Any) -> str | None:
    digits = re.sub(r"\D", "", str(value or ""))
    return digits[:8] if len(digits) >= 8 else None


def _latest_financial_row(frame: pd.DataFrame) -> dict:
    date_columns = ("日期", "报告期", "报告日期", "截止日期")
    for column in date_columns:
        if column in frame.columns:
            parsed = pd.to_datetime(frame[column], errors="coerce")
            if parsed.notna().any():
                return frame.loc[parsed.idxmax()].to_dict()
    return frame.iloc[-1].to_dict()


def _latest_complete_report_date() -> str:
    reference = datetime.now() - timedelta(days=50)
    quarter_month = ((reference.month - 1) // 3) * 3
    year = reference.year
    if quarter_month == 0:
        year -= 1
        quarter_month = 12
    day = 31 if quarter_month in (3, 12) else 30
    return f"{year:04d}{quarter_month:02d}{day:02d}"


def _normalize_history_frame(frame: pd.DataFrame, days: int) -> list[dict]:
    def column(*names: str) -> pd.Series:
        for name in names:
            if name in frame.columns:
                return frame[name]
        return pd.Series([None] * len(frame), index=frame.index)

    normalized = pd.DataFrame(
        {
            "date": column("日期", "date").astype(str),
            "open": pd.to_numeric(column("开盘", "open"), errors="coerce"),
            "high": pd.to_numeric(column("最高", "high"), errors="coerce"),
            "low": pd.to_numeric(column("最低", "low"), errors="coerce"),
            "close": pd.to_numeric(column("收盘", "close"), errors="coerce"),
            "volume": pd.to_numeric(column("成交量", "volume"), errors="coerce"),
            "amount": pd.to_numeric(column("成交额", "amount"), errors="coerce"),
            "turnover": pd.to_numeric(column("换手率", "turnover"), errors="coerce"),
        }
    ).dropna(subset=["date", "close"])
    return normalized.tail(days).to_dict(orient="records")


def _normalize_financial_row(row: dict) -> dict:
    def first(*names: str) -> float | None:
        for name in names:
            if name in row:
                value = _number(row.get(name))
                if value is not None:
                    return value
        return None

    report_date = next(
        (str(row[name]) for name in ("日期", "报告期", "报告日期", "截止日期") if row.get(name) is not None),
        None,
    )
    return {
        "report_date": report_date,
        "roe": first("净资产收益率(%)", "加权净资产收益率(%)", "净资产收益率"),
        "net_margin": first("销售净利率(%)", "净利率(%)", "销售净利率"),
        "revenue_growth": first("主营业务收入增长率(%)", "营业收入同比增长率(%)", "营业总收入同比增长率(%)"),
        "profit_growth": first("净利润增长率(%)", "净利润同比增长率(%)", "归属母公司股东的净利润同比增长率(%)"),
        "debt_ratio": first("资产负债率(%)", "资产负债率"),
        "current_ratio": first("流动比率", "流动比率(倍)"),
        "operating_cashflow_per_share": first("每股经营性现金流(元)", "每股经营现金流(元)", "每股经营性现金流"),
        "eps": first("加权每股收益(元)", "基本每股收益(元)", "每股收益(元)"),
    }


def _number(value: Any) -> float | None:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def _row_code(row: dict) -> str:
    digits = re.sub(r"\D", "", str(row.get("代码") or row.get("code") or ""))
    return digits[-6:].zfill(6) if digits else ""


def _normalize_quote(row: dict, code: str) -> dict:
    return {
        "code": code,
        "name": str(row.get("名称") or row.get("name") or ""),
        "price": _number(row.get("最新价") if "最新价" in row else row.get("trade")),
        "change_pct": _number(row.get("涨跌幅") if "涨跌幅" in row else row.get("changepercent")),
        "amount": _number(row.get("成交额") if "成交额" in row else row.get("amount")),
        "turnover": _number(row.get("换手率") if "换手率" in row else row.get("turnoverratio")),
        "pe": _number(row.get("市盈率-动态") if "市盈率-动态" in row else row.get("per")),
        "pb": _number(row.get("市净率") if "市净率" in row else row.get("pb")),
        "market_cap": _number(row.get("总市值") if "总市值" in row else row.get("mktcap")),
        "volume_ratio": _number(row.get("量比")),
    }


def _to_json_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _to_json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_json_value(item) for item in value]
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if hasattr(value, "item"):
        try:
            return _to_json_value(value.item())
        except (TypeError, ValueError):
            pass
    if value is None:
        return None
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value
