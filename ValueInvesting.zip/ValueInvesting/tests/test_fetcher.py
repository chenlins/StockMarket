from data.fetcher import DataResult, resolve_scoring_financials


class FinancialFetcher:
    def __init__(self, individual: dict, market: dict):
        self.individual = individual
        self.market = market
        self.market_calls = 0

    def get_financials(self, code):
        return DataResult(self.individual, "单股财务", "2026-01-02T00:00:00+00:00")

    def get_market_financials(self):
        self.market_calls += 1
        return DataResult(
            {"stocks": {"600001": self.market}},
            "批量财务",
            "2026-01-01T00:00:00+00:00",
        )


def test_financial_resolver_supplements_only_the_same_report_period():
    individual = {
        "report_date": "2025-12-31",
        "roe": 18,
        "net_margin": 12,
        "revenue_growth": 10,
        "profit_growth": 11,
        "debt_ratio": None,
        "current_ratio": 1.5,
        "operating_cashflow_per_share": 1.2,
        "eps": 1,
    }
    market = {
        "report_date": "2025-12-31",
        "roe": 99,
        "debt_ratio": 42,
        "annualized_eps": 2,
    }
    fetcher = FinancialFetcher(individual, market)

    result = resolve_scoring_financials(fetcher, "600001")

    assert fetcher.market_calls == 1
    assert result.data["roe"] == 18
    assert result.data["debt_ratio"] == 42
    assert result.data["annualized_eps"] == 2
    assert "同报告期" in result.source


def test_financial_resolver_does_not_mix_different_report_periods():
    individual = {
        "report_date": "2025-12-31",
        "roe": 18,
        "net_margin": 12,
        "revenue_growth": 10,
        "profit_growth": 11,
        "debt_ratio": None,
        "current_ratio": 1.5,
        "operating_cashflow_per_share": 1.2,
        "eps": 1,
    }
    market = {
        "report_date": "2025-09-30",
        "debt_ratio": 20,
        "annualized_eps": 3,
    }

    result = resolve_scoring_financials(FinancialFetcher(individual, market), "600001")

    assert result.data["report_date"] == "2025-12-31"
    assert result.data["debt_ratio"] is None
    assert "annualized_eps" not in result.data
    assert "报告期不同" in result.source
